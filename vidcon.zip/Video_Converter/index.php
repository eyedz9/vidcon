<?php 
include("templates/header.php");?>
<!-- Start Content Wrapper -->
<div id="contentWrapper">

<!-- Start Body Area -->
<div id="bodyArea">
    <div class="google_ads">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- video converter -->
        <ins class="adsbygoogle"
             style="display:inline-block;width:728px;height:90px"
             data-ad-client="ca-pub-8566298613299826"
             data-ad-slot="3492396198"></ins>
        <script>
        (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
<h1 class="headLeft" >Video Converter php script:</h1>

<div id="features">
<ul>
	<li>Convert all videos to MP4, MP3, etc. for various media players</li>
	<li>Extract audio from video like mp3 format</li>
	<li>Choose the video and the audio quality</li>
	<li>Upload video from your pc or a remote server</li>
</ul>
</div>
    <div class="google_ads">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- video converter -->
        <ins class="adsbygoogle"
             style="display:inline-block;width:728px;height:90px"
             data-ad-client="ca-pub-8566298613299826"
             data-ad-slot="3492396198"></ins>
        <script>
        (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>


<?php

require_once("languages/en.php");
include ("includes/settings.php");
include("includes/functions.php");
include("includes/LIB_parse.php");
include("classes/other.php");
cron(); // to run cron job to delete all files
if(isset($_POST['uploader_0_name']) or isset ($_GET['uploaded_name'])) 
	{
	if(isset($_POST['uploader_0_name'])) 
	{
list($_SESSION['original_name'], $ext) = explode('.',$_POST['uploader_0_name']);
}else{
$fullname=$_GET['uploaded_name'];
}
if(isset($_POST['uploader_0_name'])) 
	{
list($_SESSION['original_name'], $ext) = explode('.',$_POST['uploader_0_name']);
}else{
list($_SESSION['original_name'], $ext) = explode('.',$_GET['uploaded_name']);
$_SESSION['original_name']= return_between($_GET['uploaded_name'], '_', "$ext", 'EXCL') ;
$_SESSION['original_name']= str_replace(".","",$_SESSION['original_name']); 
}
if(isset($_POST['uploader_0_name'])) 
	{	
$fullname=	$_POST['uploader_0_tmpname'];
}else{
$fullname=$_GET['uploaded_name'];
}
$ext= pathinfo($fullname, PATHINFO_EXTENSION); 
$_SESSION['name']=RemoveExtension($fullname);
$store_dir="uploaded/";
$_SESSION['converted_vids']=$converted_vids;
$_SESSION['temp_dir']=$store_dir;
// if those directotires don't exist - create them and give them read/write permissions
if(!is_dir($store_dir)) mkdir($store_dir, 0777); 
if(!is_dir($converted_vids)) mkdir($converted_vids, 0777);
$extension = substr($fullname, strrpos($fullname, "."));
$extension = strtolower($extension);
$video_to_convert=$store_dir.$_SESSION['name'];
$_SESSION['video_to_convert']=$video_to_convert;
$_SESSION['extension']=$extension;
/*******************************
check extenxions 
***************************************************/	
			      if (!in_array($ext, $allowedExtensions))
                  {
                    echo '<div  style="text-align:center"><strong>'.$ext."</strong><br> is an invalid file type!<br>Supported files are:<br><strong>";
                    foreach ($allowedExtensions as $value) { echo $value . "<br>"; }
                    echo "</strong><br>";
        echo "<a href=\"index.php\">"."<img src=\"images/red-back.png\" border=\"0\" /></a></div>";
         include("templates/footer.php");
                       exit;
                  }
				  
				  
			?>
			
			<center>
<form name="choose" action="index.php" method="post" target="_self">
				<br />
								<fieldset >
							<legend class="show_legend">Convert To</legend>
							
				<div class="radio_buttons">
				<img alt="" src="images/flv.jpg" class="format_button">
				<input  name="type" type="radio" class="blue_font" value="flv" onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');";/>
				<img alt="" src="images/mp4.jpg" class="format_button">
				<input name="type" type="radio" value="mp4"  onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');"/>
				<img alt="" src="images/wmv.png" class="format_button">
				<input name="type" type="radio" value="wmv" onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');" />
				<img alt="" src="images/avi.png" class="format_button">
				<input name="type" type="radio" value="avi" onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');"/>
				<img alt="" src="images/mp3.png" class="format_button">
				<input name="type" type="radio" value="mp3" onclick="javascript:document.choose.quality.disabled=true;document.choose.audio.disabled=false;document.choose.size.disabled=true;document.choose.OK.disabled=false;showStuff('send_next');" /> 
				<img alt="" src="images/ogg.png" class="format_button">
				<input name="type" type="radio" value="ogg" onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');"/>
				<img alt="" src="images/webm.png" class="format_button">
				<input name="type" type="radio" value="webm" onclick="javascript:document.choose.quality.disabled=false;document.choose.audio.disabled=false;document.choose.size.disabled=false;document.choose.OK.disabled=false;showStuff('send_next');"/>
				</div>
				</fieldset>
					<fieldset >
							<legend class="show_legend">Optional settings</legend>

				<div class="radio_buttons"style="display:inline;padding:10px" >
				<br />Video quality:
				<select name="quality" class="radio_buttons" disabled="disabled">
				  <option  value="2000000" >high</option>
				  <option value="1000000">medium</option>
				  <option value="800000">low</option>
				</select>
				</div>
			
				<div class="radio_buttons"style="display:inline;padding:10px" >Audio quality:
				<select name="audio" class="radio_buttons" disabled="disabled">
				  <option value="44100" >high</option>
				  <option value="22050">medium</option>
				  <option name="low" value="11025" >low</option>
				</select>
				
				
				<div class="radio_buttons"style="display:inline;padding:10px" >Video size:
				<select name="size" class="radio_buttons" disabled="disabled" >
				  <option value="320x240">320x240</option>
				  <option value="512x384" selected="selected">512x384</option>
				  <option value="640x360">640x360</option>
				  <option value="854x480">854x480</option>
				  <option value="1280x720">1280x720</option>
				</select>
				</div>
				
				</fieldset>
				<div class="radio_buttons">
				
				  
				   <input name="OK" type="submit" disabled="disabled" value="" id="send_next"  style="display:none"/>
				</div>
  </form >

  </center>
<?php
	}
	elseif(isset($_POST['type']))
		{
		
		
		$new_format=htmlspecialchars($_POST['type']); // read output format from form
		$name = $_SESSION['name'];
		//$_SESSION['extension'];
		$video_to_convert=$store_dir.$_SESSION['name'].$_SESSION['extension'];
		
		
		if (isset($_POST['size'])) {$size=$_POST['size'];} 
		if (isset($_POST['quality'])) {$quality=$_POST['quality'];}
		if (isset($_POST['audio'])) {$audio=$_POST['audio'];}
				
		if($new_format=="webm" && $audio=="11025"){$audio="22050";$new_format="webm"; }// for webm  and ogg audio can not be 11050
		if($new_format=="ogg" && $audio=="11025"){$audio="22050"; $new_format="ogg"; }// for webm  and ogg audio can not be 11050
		
		$_SESSION['type']=$new_format;
		
		
		if($new_format=="flv"){ $call=$ffmpeg." -i ".$video_to_convert." -vcodec flv -f flv -r 30 -b ".$quality." -ab 128000 -ar ".$audio." -s ".$size." ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	
	if($new_format=="avi"){ $call=$ffmpeg." -i ".$video_to_convert." -vcodec mjpeg -f avi -acodec libmp3lame -b ".$quality." -s ".$size." -r 30 -g 12 -qmin 3 -qmax 13 -ab 224 -ar ".$audio." -ac 2 ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	if($new_format=="mp3"){ $call=$ffmpeg." -i ".$video_to_convert." -vn -acodec libmp3lame -ac 2 -ab 128000 -ar ".$audio."  ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	if($new_format=="mp4"){ $call=$ffmpeg." -i ".$video_to_convert."  -vcodec mpeg4 -r 30 -b ".$quality." -acodec libmp3lame -ab 126000 -ar ".$audio." -ac 2 -s ".$size." ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	if($new_format=="wmv"){ $call=$ffmpeg." -i ".$video_to_convert." -vcodec wmv1 -r 30 -b ".$quality." -acodec wmav2 -ab 128000 -ar ".$audio." -ac 2 -s ".$size." ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	if($new_format=="ogg"){ $call=$ffmpeg." -i ".$video_to_convert." -vcodec libtheora -r 30 -b ".$quality." -acodec libvorbis -ab 128000   -ar ".$audio." -ac 2 -s ".$size." ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	if($new_format=="webm"){ $call=$ffmpeg." -i ".$video_to_convert." -vcodec libvpx  -r 30 -b ".$quality." -acodec libvorbis -ab 128000   -ar ".$audio." -ac 2 -s ".$size." ".$converted_vids.$name.".".$new_format." -y 2> log/".$name.".txt";}
	
	
/* START CONVERTING The Video */
		
	require_once("includes/ffmpeg_cmd.php"); 

	$convert = (popen($convert_call, "r"));
	
	pclose($convert);
	flush();	
// define sessions

	
	$_SESSION['dest_file']=$converted_vids.$name.".".$new_format;

	 echo "<script>\n";
	 echo "counter = 5\n";
	  echo "var redirect = 0; \n";
	  echo "$(document).ready(function()\n";
  echo "{\n";
	echo "var refreshId = setInterval(function() \n";
	 echo "{\n";
   	 echo "if(redirect == 0) \n { \n";
	 echo "$('#timeval').load('progress_bar.php');\n";
	 echo "}\n";
	 echo "else \n";
	 echo "{\n";
	 echo "$('#timeval').load('progress_bar.php?counter='+ counter--);\n";
	 echo "}\n";
	 echo "}, 1000);\n";
    echo "});\n";	
	echo "</script>\n";
	
	// 
	/*************************  for debug        *************************************
	echo "<pre>";
	print_r ($_SESSION);
	echo "<pre>";
	**********************************************************************************/
  
  ?>


<!-- div to display results from progress_bar.php  -->
<center>
<div id="timeval"><img src="images/wait.gif" alt="wait please"  /><br /></div>
</center>
	<?php	
		}
	

		
		
		else if(isset($_GET['finished']))
		{
					echo "<center>";
					if(!isset($_SESSION['name'])) { echo "<a href=\"index.php\">please convert new video</a>";include("templates/footer.php");;exit;}
					// remove punctation from the file name
                                        $vid_name = $_SESSION['name'].".".$_SESSION['type'];
                                        $filepath = $converted_vids.$vid_name;
					
					echo "<a href=\"".$filepath."\"> <img src=\"images/download.jpg\"></a>" ;
					
					require_once"video_duration.php";
					
					
					$_SESSION['duration']=$hours.":".$minutes.":".$seconds;
                                        
                                        $vid_name=$_SESSION['name'];
                    $vid_src=$_SESSION['extension'];
                    $vid_new=$_SESSION['type'];
                    if (isset($_SESSION['duration'])) {$duration=$_SESSION['duration'];}else {$duration="unknown";}
                    if(file_exists($converted_vids.$vid_name.".".$vid_new))
                        {
                            $vid_size=get_size($converted_vids.$vid_name.".".$vid_new);
                        }else {$vid_size=0;    }
                    
                    
                    
                    
                    
					?>
                    
                    <div class="video_infor">your video information</div>
					<table border="1" class="info_table">
	<tr>
		<td>Video duration</td>
		<td><?php echo $hours.":".$minutes.":".$seconds;?></td>
	</tr>
	<tr>
		<td>original video name</td>
		<td><?php if(isset($_SESSION['original_name'])){echo $_SESSION['original_name'];} ?></td>
	</tr>
	<tr>
		<td>video size</td>
		<td><?php  echo $vid_size." MB<br>"; ?></td>
	</tr>
	<tr>
		<td>source extension</td>
		<td><?php echo str_replace(".","","$vid_src"); ?></td>
	</tr>
        <tr>
        <td>new extension</td>
        <td><?php echo $vid_new; ?></td>
    </tr>
</table>

					
					<?php
					
					echo "</center>";
					

					session_unset();
					
				
				
		}
		
		
	else 
		{
			?>
			<center>
<script type="text/javascript">
// Convert divs to queue widgets when the DOM is ready
$(function() {
	$("#uploader").pluploadQueue({
		// General settings
		runtimes : 'flash',
		url : 'upload.php',
		max_file_size : '<?php echo $max_file_size ;?>mb',
		chunk_size : '1mb',
		unique_names : true,

		// Resize images on clientside if we can
		resize : {width : 320, height : 240, quality : 90},
init : {
              FilesAdded: function(up, files) {
                plupload.each(files, function(file) {
                  if (up.files.length > 1) {
                    up.removeFile(file);
                  }
                });
                if (up.files.length >= 1) {
                  $('#pickfiles').hide('slow');
                }
              },
              FilesRemoved: function(up, files) {
                if (up.files.length < 1) {
                  $('#pickfiles').fadeIn('slow');
                }
              }
            },
            multi_selection: false,
		// Specify what files to browse for
		filters : [
			{title : "Video files", extensions : "<?php foreach ($allowedExtensions as $value) { echo $value . ","; }?>"}
			
		],

		// Flash settings
		flash_swf_url : 'js/plupload.flash.swf',

		// Silverlight settings
		silverlight_xap_url : 'js/plupload.silverlight.xap'
	});

	// Client side form validation
	$('form').submit(function(e) {
        var uploader = $('#uploader').pluploadQueue();

        // Files in queue upload them first
        if (uploader.files.length > 0) {
            // When all files are uploaded submit form
            uploader.bind('StateChanged', function() {
                if (uploader.files.length === (uploader.total.uploaded + uploader.total.failed)) {
                    $('form')[0].submit();
                }
            });
                
            uploader.start();
        } else {
            alert('You must queue at least one video.');
        }

        return false;
    });
});
</script>
<form method="post" action="index.php">
	<div id="uploader">
		<p>You browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 support.</p>
	</div>
	<input type="submit" value="" id="send_next" />
</form>
  <p class="size_limit">Maximum upload size <?php echo $max_file_size ;?> MB<p>
  </center>
  <?php include("templates/info.php");?>
<?php 
		}
		
		
//End Body Area/


//Footer 
include("templates/footer.php");
?>