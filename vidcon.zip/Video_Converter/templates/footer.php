<?php
// You can do something here before finish executing the script
?>
<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=10762707; 
var sc_invisible=1; 
var sc_security="b45ff64d"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="shopify
analytics tool" href="http://statcounter.com/shopify/"
target="_blank"><img class="statcounter"
src="http://c.statcounter.com/10762707/0/b45ff64d/1/"
alt="shopify analytics tool"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47226813-1', 'phpvideoconverter.com');
  ga('send', 'pageview');

</script>
<div id="footer">
 <p class="copyright">Powered by: <b>
	<a title="Video Converter php script v1.0"  href="#" >
	Video Converter php script v1.8</a></b><br /> &#64; 2012-<script type="text/javascript">var d = new Date(); document.write(d.getFullYear());</script> 
	Video Converter php script. All Rights Reserved</p>
</div>
</body>
</html>