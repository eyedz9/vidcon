﻿<table width="60%" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>


<div class="leftcol">

	<img  style=" float: left; margin: 4px; "src="images/flv.png" >
<p class="middle">FLV Format</p>	
<p class="format"> Flash Video is a container file format played using Adobe Flash Player.</p>
</div>
<div class="rightcol">

			<img  style=" float: left; margin: 4px; "src="images/avatar.png" >
<p class="middle">High quality </p>				
<p>The site download videos in the highest quality available.  </p>
</div>


<div align="center">
</div>
<div align="center">



</div>
</td>
</tr>
</table>
<table width="60%" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>


<div class="leftcol">

	<img  style=" float: left; margin: 4px; "src="images/3gp2.png" >
	<p class="middle">3GP Format</p>
<p>3GP format is a multimedia format. It is used on 3G mobile phones.</p>
</div>
<div class="rightcol">

			<img  style=" float: left; margin: 4px; "src="images/mp42.png" >
			<p class="middle">MPEG-4 Format</p>
<p>It is used to store digital video and digital audio streams. </p>
</div>


<div align="center">
</div>
<div align="center">



</div>
</td>
</tr>
</table>