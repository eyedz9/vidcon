<?php
if (!isset($_SESSION)) 
{
  session_start();
}
// You can do some initialization for the template here
@date_default_timezone_set(date_default_timezone_get());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link title="voottavar Style" href="templates/styles/rl_style_pm.css" rel="stylesheet" type="text/css" />

<title> Video Converter php script </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<script src="js/jquery.js""></script>
<script src="js/converter.js""></script>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">@import url(js/jquery.plupload.queue/css/jquery.plupload.queue.css);</style>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>

<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) -->
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>

<!-- Load plupload and all it's runtimes and finally the jQuery queue widget -->
<script type="text/javascript" src="js/plupload.full.js"></script>
<script type="text/javascript" src="js/jquery.plupload.queue/jquery.plupload.queue.js"></script>

<link href="templates/styles/rl_style_pm.css" rel="stylesheet" type="text/css" />
</head>

<body>
<!-- Start Site Wrapper -->
<div id="wrapper">

<!-- Top Bar -->

<!-- End Top Bar -->

<!-- Start Header -->
<div id="header">
 <img src="images/header.png" alt="video converter" title="video converter" />
<p id="header_p"> 

<a href="http://bit.ly/13GbRD7"><img src="images/buy.png" alt="Video Converter php script" title="Video Converter php script" /></a>
</p>

</div>
<!-- End Header -->

<!-- Start Menu Bar -->
<div id="menu">
  <table  cellspacing="0" cellpadding="0">
  <tr>
    <td><a href="index.php" title="Home" <?php if($pos = strpos($_SERVER["PHP_SELF"], "index.php")!==false) echo "class=\"first\""; ?>>PC UPLOAD</a></td>
    <td><a href="remote.php" title="Installation" <?php if($pos = strpos($_SERVER["PHP_SELF"], "remote.php")!==false) echo "class=\"first\""; ?>>Remote UPLOAD</a></td>
    <td><a href="contact.php" title="contact us" <?php if($pos = strpos($_SERVER["PHP_SELF"], "contact.php")!==false) echo "class=\"first\""; ?>>CONTACT US</a></td>
  </tr>
  </table>
</div>
<div  class="under_nav"></div>
<!-- End Menu Bar -->
