<?php
include ('includes/settings.php');
$delete_all_files = $delete_files*60*60;  // to delete after the number of hours
# to deletea all files from the uploaded folder 
$files = glob('uploaded/*');

foreach($files as $file) {
if ( filemtime($file) <= time()-$delete_all_files ) {
    unlink($file);
	 }
}
# to deletea all files from the log folder 
$files = glob('log/*');

foreach($files as $file) {
if ( filemtime($file) <= time()-$delete_all_files ) {
    unlink($file);
	 }
}
# to deletea all files from the converted_videos folder 
$files = glob('converted_videos/*');

foreach($files as $file) {
if ( filemtime($file) <= time()-$delete_all_files ) {
    unlink($file);
	 }
}
?>
